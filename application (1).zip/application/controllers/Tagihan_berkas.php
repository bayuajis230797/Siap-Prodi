<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Tagihan Berkas Controller (untuk Mahasiswa)
 * Mahasiswa dapat melihat tagihan dan upload file
 */
class Tagihan_berkas extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->check_role('mahasiswa');
        
        $this->load->model('Tagihan_berkas_model');
        $this->load->helper('menu');
        $this->load->library('form_validation');
        $this->load->helper('file');
    }

    /**
     * Index - Daftar tagihan mahasiswa
     */
    public function index() {
        $id_mahasiswa = $this->session->userdata('ref_id');
        
        if (!$id_mahasiswa) {
            $this->session->set_flashdata('error', 'Data mahasiswa tidak ditemukan.');
            redirect('Dashboard');
        }
        
        $data['title'] = 'Tagihan Berkas';
        $data['page_title'] = 'Tagihan Berkas';
        $data['breadcrumb'] = array(
            array('label' => 'Tagihan Berkas', 'active' => true)
        );
        $data['sidebar_menu'] = generate_sidebar_menu('mahasiswa');
        
        // Get tagihan untuk mahasiswa ini
        $data['tagihan_list'] = $this->Tagihan_berkas_model->get_by_mahasiswa($id_mahasiswa, 1);
        
        // Get detail untuk setiap tagihan
        foreach ($data['tagihan_list'] as $tagihan) {
            $tagihan->detail = $this->Tagihan_berkas_model->get_detail_by_mahasiswa_tagihan($tagihan->id, $id_mahasiswa);
        }
        
        $data['content'] = $this->load->view('tagihan_berkas/index', $data, true);
        $this->load->view('layouts/main', $data);
    }

    /**
     * Detail tagihan
     */
    public function detail($id) {
        $id_mahasiswa = $this->session->userdata('ref_id');
        
        if (!$id_mahasiswa) {
            $this->session->set_flashdata('error', 'Data mahasiswa tidak ditemukan.');
            redirect('Dashboard');
        }
        
        $tagihan = $this->Tagihan_berkas_model->get_by_id($id);
        
        if (!$tagihan) {
            $this->session->set_flashdata('error', 'Tagihan tidak ditemukan.');
            redirect('Tagihan_berkas');
        }
        
        // Cek apakah tagihan untuk mahasiswa ini
        $detail = $this->Tagihan_berkas_model->get_detail_by_mahasiswa_tagihan($id, $id_mahasiswa);
        
        if (!$detail) {
            $this->session->set_flashdata('error', 'Anda tidak memiliki akses ke tagihan ini.');
            redirect('Tagihan_berkas');
        }
        
        $data['title'] = 'Detail Tagihan Berkas';
        $data['page_title'] = 'Detail Tagihan Berkas';
        $data['breadcrumb'] = array(
            array('label' => 'Tagihan Berkas', 'url' => site_url('Tagihan_berkas')),
            array('label' => 'Detail', 'active' => true)
        );
        $data['sidebar_menu'] = generate_sidebar_menu('mahasiswa');
        
        $data['tagihan'] = $tagihan;
        $data['detail'] = $detail;
        
        $data['content'] = $this->load->view('tagihan_berkas/detail', $data, true);
        $this->load->view('layouts/main', $data);
    }

    /**
     * Upload file untuk tagihan softfile
     */
    public function upload($id) {
        $id_mahasiswa = $this->session->userdata('ref_id');
        
        if (!$id_mahasiswa) {
            $this->session->set_flashdata('error', 'Data mahasiswa tidak ditemukan.');
            redirect('Dashboard');
        }
        
        $tagihan = $this->Tagihan_berkas_model->get_by_id($id);
        
        if (!$tagihan) {
            $this->session->set_flashdata('error', 'Tagihan tidak ditemukan.');
            redirect('Tagihan_berkas');
        }
        
        // Cek apakah tagihan softfile
        if ($tagihan->is_hardcopy == 1) {
            $this->session->set_flashdata('error', 'Tagihan ini adalah hardcopy, tidak perlu upload file.');
            redirect('Tagihan_berkas/detail/' . $id);
        }
        
        // Cek apakah tagihan untuk mahasiswa ini
        $detail = $this->Tagihan_berkas_model->get_detail_by_mahasiswa_tagihan($id, $id_mahasiswa);
        
        if (!$detail) {
            $this->session->set_flashdata('error', 'Anda tidak memiliki akses ke tagihan ini.');
            redirect('Tagihan_berkas');
        }
        
        if ($this->input->method() === 'post') {
            // Konfigurasi upload
            $upload_path = './uploads/tagihan_berkas/';
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = 'pdf|doc|docx|xls|xlsx|jpg|jpeg|png';
            $config['max_size'] = 10240; // 10MB
            $config['encrypt_name'] = TRUE;
            
            $this->load->library('upload', $config);
            
            if (!$this->upload->do_upload('file_berkas')) {
                $error = $this->upload->display_errors('', '');
                $this->session->set_flashdata('error', $error);
                redirect('Tagihan_berkas/detail/' . $id);
            } else {
                $upload_data = $this->upload->data();
                
                // Hapus file lama jika ada
                if ($detail->file_path && file_exists($detail->file_path)) {
                    unlink($detail->file_path);
                }
                
                // Update detail
                $update_data = array(
                    'file_path' => $upload_path . $upload_data['file_name'],
                    'file_name' => $upload_data['orig_name'],
                    'file_size' => $upload_data['file_size'],
                    'status' => 'sudah',
                    'uploaded_at' => date('Y-m-d H:i:s')
                );
                
                $this->Tagihan_berkas_model->update_detail($detail->id, $update_data);
                
                $this->session->set_flashdata('success', 'File berhasil diupload.');
                redirect('Tagihan_berkas/detail/' . $id);
            }
        } else {
            redirect('Tagihan_berkas/detail/' . $id);
        }
    }

    /**
     * Download file
     */
    public function download($id) {
        $id_mahasiswa = $this->session->userdata('ref_id');
        
        if (!$id_mahasiswa) {
            $this->session->set_flashdata('error', 'Data mahasiswa tidak ditemukan.');
            redirect('Dashboard');
        }
        
        $tagihan = $this->Tagihan_berkas_model->get_by_id($id);
        
        if (!$tagihan) {
            $this->session->set_flashdata('error', 'Tagihan tidak ditemukan.');
            redirect('Tagihan_berkas');
        }
        
        $detail = $this->Tagihan_berkas_model->get_detail_by_mahasiswa_tagihan($id, $id_mahasiswa);
        
        if (!$detail || !$detail->file_path || !file_exists($detail->file_path)) {
            $this->session->set_flashdata('error', 'File tidak ditemukan.');
            redirect('Tagihan_berkas/detail/' . $id);
        }
        
        $this->load->helper('download');
        force_download($detail->file_name, file_get_contents($detail->file_path));
    }

    /**
     * Delete file
     */
    public function delete_file($id) {
        $id_mahasiswa = $this->session->userdata('ref_id');
        
        if (!$id_mahasiswa) {
            $this->session->set_flashdata('error', 'Data mahasiswa tidak ditemukan.');
            redirect('Dashboard');
        }
        
        $tagihan = $this->Tagihan_berkas_model->get_by_id($id);
        
        if (!$tagihan) {
            $this->session->set_flashdata('error', 'Tagihan tidak ditemukan.');
            redirect('Tagihan_berkas');
        }
        
        $detail = $this->Tagihan_berkas_model->get_detail_by_mahasiswa_tagihan($id, $id_mahasiswa);
        
        if (!$detail) {
            $this->session->set_flashdata('error', 'Anda tidak memiliki akses ke tagihan ini.');
            redirect('Tagihan_berkas');
        }
        
        // Hapus file
        if ($detail->file_path && file_exists($detail->file_path)) {
            unlink($detail->file_path);
        }
        
        // Update detail
        $update_data = array(
            'file_path' => null,
            'file_name' => null,
            'file_size' => null,
            'status' => 'belum',
            'uploaded_at' => null
        );
        
        $this->Tagihan_berkas_model->update_detail($detail->id, $update_data);
        
        $this->session->set_flashdata('success', 'File berhasil dihapus.');
        redirect('Tagihan_berkas/detail/' . $id);
    }
}

