<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Pkl_klaim_nilai Controller
 * Menangani klaim nilai PKL oleh mahasiswa
 */
class Pkl_klaim_nilai extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->check_role('mahasiswa');
        $this->load->model('Pkl_klaim_nilai_model');
        $this->load->model('Pkl_berkas_klaim_upload_model');
        $this->load->model('Pkl_berkas_klaim_nilai_model');
        $this->load->model('Pkl_nilai_rekap_model');
        $this->load->model('Tahun_akademik_model');
        $this->load->library('form_validation');
        $this->load->helper('file');
        $this->load->helper('google_drive');
        $this->load->helper('notifikasi');
    }

    /**
     * Index - form klaim nilai PKL
     */
    public function index() {
        $id_mahasiswa = $this->session->userdata('ref_id');
        $tahun_aktif = $this->Tahun_akademik_model->get_aktif();
        
        if (!$tahun_aktif) {
            $this->session->set_flashdata('error', 'Tidak ada tahun akademik aktif.');
            redirect('Halaman_utama');
        }

        // Cek apakah sudah ada penilaian dari penguji
        $this->load->model('Pkl_penilaian_model');
        $penilaian_penguji = $this->Pkl_penilaian_model->get_by_mahasiswa_tipe($id_mahasiswa, $tahun_aktif->id, 'penguji');
        
        if (!$penilaian_penguji) {
            $this->session->set_flashdata('error', 'Anda belum memiliki penilaian dari penguji. Pastikan sidang sudah dilakukan dan penguji sudah memberikan penilaian.');
            redirect('Halaman_utama');
        }

        // Cek apakah sudah ada klaim
        $klaim = $this->Pkl_klaim_nilai_model->get_by_mahasiswa($id_mahasiswa, $tahun_aktif->id);
        
        // Ambil berkas yang sudah diupload
        $berkas_uploaded = array();
        if ($klaim) {
            $berkas_uploaded = $this->Pkl_berkas_klaim_upload_model->get_by_klaim($klaim->id);
        }

        // Ambil daftar berkas yang diperlukan
        $berkas_list = $this->Pkl_berkas_klaim_nilai_model->get_all(true);

        // Ambil nilai rekap jika sudah ada
        $nilai_rekap = $this->Pkl_nilai_rekap_model->get_by_mahasiswa($id_mahasiswa, $tahun_aktif->id);

        $this->load->library('Bimbingan_pasca_service');
        $pasca_status = $this->bimbingan_pasca_service->pkl_klaim_status($id_mahasiswa, $tahun_aktif->id);

        $data = array(
            'title' => 'Klaim Nilai PKL',
            'page_title' => 'Klaim Nilai PKL',
            'breadcrumb' => array(
                array('label' => 'PKL', 'url' => '#'),
                array('label' => 'Klaim Nilai', 'active' => true)
            ),
            'sidebar_menu' => generate_sidebar_menu('mahasiswa'),
            'klaim' => $klaim,
            'berkas_list' => $berkas_list,
            'berkas_uploaded' => $berkas_uploaded,
            'nilai_rekap' => $nilai_rekap,
            'tahun_aktif' => $tahun_aktif,
            'pasca_status' => $pasca_status,
            'boleh_klaim' => !empty($pasca_status['ok']),
        );

        $data['content'] = $this->load->view('mahasiswa/pkl_klaim_nilai/index', $data, true);
        $this->load->view('layouts/main', $data);
    }

    /**
     * Submit klaim nilai PKL
     */
    public function submit() {
        $id_mahasiswa = $this->session->userdata('ref_id');
        $tahun_aktif = $this->Tahun_akademik_model->get_aktif();
        
        if (!$tahun_aktif) {
            $this->session->set_flashdata('error', 'Tidak ada tahun akademik aktif.');
            redirect('Halaman_utama');
        }

        // Cek apakah sudah ada penilaian dari penguji
        $this->load->model('Pkl_penilaian_model');
        $penilaian_penguji = $this->Pkl_penilaian_model->get_by_mahasiswa_tipe($id_mahasiswa, $tahun_aktif->id, 'penguji');
        
        if (!$penilaian_penguji) {
            $this->session->set_flashdata('error', 'Anda belum memiliki penilaian dari penguji.');
            redirect('Halaman_utama');
        }

        $this->load->library('Bimbingan_pasca_service');
        $pasca_status = $this->bimbingan_pasca_service->pkl_klaim_status($id_mahasiswa, $tahun_aktif->id);
        if (empty($pasca_status['ok'])) {
            $this->session->set_flashdata('error', isset($pasca_status['message']) ? $pasca_status['message'] : 'Menunggu penguji menyatakan layak klaim nilai.');
            redirect('Pkl_klaim_nilai');
        }

        // Cek apakah sudah ada klaim
        $klaim = $this->Pkl_klaim_nilai_model->get_by_mahasiswa($id_mahasiswa, $tahun_aktif->id);
        
        // Ambil daftar berkas wajib
        $berkas_list = $this->Pkl_berkas_klaim_nilai_model->get_all(true);
        $berkas_wajib = array();
        foreach ($berkas_list as $berkas) {
            if ($berkas->wajib) {
                $berkas_wajib[] = $berkas->id;
            }
        }

        // Validasi link wajib
        $errors = array();
        foreach ($berkas_wajib as $id_berkas) {
            $link_berkas = trim($this->input->post('link_berkas_' . $id_berkas));
            if (empty($link_berkas)) {
                // Cek apakah sudah pernah diupload
                if ($klaim) {
                    $existing = $this->Pkl_berkas_klaim_upload_model->get_by_klaim_berkas($klaim->id, $id_berkas);
                    if (!$existing) {
                        $errors[] = "Berkas wajib belum diisi";
                        break;
                    }
                    if (!is_valid_google_drive_link((string) $existing->file_path)) {
                        $errors[] = "Terdapat link berkas wajib yang belum valid. Silakan perbarui link Google Drive.";
                        break;
                    }
                } else {
                    $errors[] = "Berkas wajib belum diisi";
                    break;
                }
            } else {
                if (!is_valid_google_drive_link($link_berkas)) {
                    $errors[] = "Link wajib menggunakan format Google Drive/Docs yang valid";
                    break;
                }
            }
        }

        if (!empty($errors)) {
            $this->session->set_flashdata('error', implode(', ', $errors));
            redirect('Pkl_klaim_nilai');
        }

        // Buat atau update klaim
        if (!$klaim) {
            $klaim_data = array(
                'id_mahasiswa' => $id_mahasiswa,
                'id_tahun_akademik' => $tahun_aktif->id,
                'status' => 'menunggu'
            );
            $klaim_id = $this->Pkl_klaim_nilai_model->create($klaim_data);
        } else {
            $klaim_id = $klaim->id;
            // Update status jika ditolak sebelumnya
            if ($klaim->status == 'ditolak') {
                $this->Pkl_klaim_nilai_model->update($klaim_id, array('status' => 'menunggu'));
            }
        }

        // Simpan link berkas
        foreach ($berkas_list as $berkas) {
            $field_name = 'link_berkas_' . $berkas->id;
            $link_berkas = trim($this->input->post($field_name));
            
            if (!empty($link_berkas)) {
                if (!is_valid_google_drive_link($link_berkas)) {
                    continue; // Skip jika bukan link Google Drive
                }
                $normalized_link = normalize_google_drive_link($link_berkas);
                
                // Cek apakah sudah ada upload sebelumnya
                $existing = null;
                if ($klaim) {
                    $existing = $this->Pkl_berkas_klaim_upload_model->get_by_klaim_berkas($klaim_id, $berkas->id);
                }
                
                // Nama file dari nama berkas
                $file_name = $berkas->nama_berkas;
                
                if ($existing) {
                    // Hapus file lama hanya jika bukan link (backward compatibility)
                    if (strpos($existing->file_path, 'http') === false && file_exists($existing->file_path)) {
                        unlink($existing->file_path);
                    }
                    // Update
                    $this->Pkl_berkas_klaim_upload_model->update($existing->id, array(
                        'file_path' => $normalized_link,
                        'file_name' => $file_name,
                        'file_size' => null
                    ));
                } else {
                    // Create
                    $this->Pkl_berkas_klaim_upload_model->create(array(
                        'id_klaim_nilai' => $klaim_id,
                        'id_berkas_klaim_nilai' => $berkas->id,
                        'file_path' => $normalized_link,
                        'file_name' => $file_name,
                        'file_size' => null
                    ));
                }
            }
        }

        send_in_app_notification_by_role(
            'sekprodi',
            'Klaim Nilai PKL Baru',
            'Ada klaim nilai PKL baru yang menunggu verifikasi.',
            site_url('Pkl_verifikasi_klaim')
        );

        $this->session->set_flashdata('success', 'Klaim nilai berhasil dikirim. Menunggu persetujuan dari sekprodi.');
        redirect('Pkl_klaim_nilai');
    }
}





