<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Profile Controller
 * Untuk semua role mengubah username dan password
 */
class Profile extends MY_Controller {

    public function __construct() {
        parent::__construct();
        // Bisa diakses semua role yang sudah login
        if (!$this->session->userdata('user_id')) {
            redirect('Auth');
        }
        $this->load->model('User_model');
    }

    /**
     * Form ganti username dan password
     */
    public function index() {
        $user_id = $this->session->userdata('user_id');
        $user = $this->User_model->get_user_by_id($user_id);
        
        if (!$user) {
            $this->session->set_flashdata('error', 'Data user tidak ditemukan.');
            redirect('Dashboard');
        }

        if ($this->input->method() === 'post') {
            $this->form_validation->set_rules('password_lama', 'Password Lama', 'required|trim');
            $this->form_validation->set_rules('password_baru', 'Password Baru', 'required|trim|min_length[5]');
            $this->form_validation->set_rules('password_baru_confirm', 'Konfirmasi Password Baru', 'required|trim|matches[password_baru]');

            if ($this->form_validation->run() == FALSE) {
                $data['user'] = $user;
                $data['title'] = 'Ganti Password';
                $data['page_title'] = 'Ganti Password';
                $data['breadcrumb'] = array(
                    array('label' => 'Profile', 'active' => true)
                );
                $role = $this->session->userdata('role');
                $data['sidebar_menu'] = generate_sidebar_menu($role);
                $data['content'] = $this->load->view('profile/index', $data, true);
                $this->load->view('layouts/main', $data);
            } else {
                $password_lama = $this->input->post('password_lama');
                $password_baru = $this->input->post('password_baru');
                
                // Validasi password lama
                $current_user = $this->User_model->check_login($user->username, $password_lama);
                if (!$current_user) {
                    $this->session->set_flashdata('error', 'Password lama tidak benar.');
                    redirect('Profile');
                }
                
                // Update password
                $update_data = array('password' => trim($password_baru));
                
                if ($this->User_model->update($user_id, $update_data)) {
                    $this->session->set_flashdata('success', 'Password berhasil diubah.');
                    redirect('Profile');
                } else {
                    $this->session->set_flashdata('error', 'Gagal mengubah password.');
                    redirect('Profile');
                }
            }
        } else {
            $data['user'] = $user;
            $data['title'] = 'Ganti Password';
            $data['page_title'] = 'Ganti Password';
            $data['breadcrumb'] = array(
                array('label' => 'Profile', 'active' => true)
            );
            $role = $this->session->userdata('role');
            $data['sidebar_menu'] = generate_sidebar_menu($role);
            $data['content'] = $this->load->view('profile/index', $data, true);
            $this->load->view('layouts/main', $data);
        }
    }
}

