<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notifikasi extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Notifikasi_model');
    }

    public function mark_read($id) {
        $user_id = $this->session->userdata('user_id');
        $role = $this->session->userdata('role');
        
        if (!$user_id) {
            show_404();
        }
        
        $notifikasi = $this->Notifikasi_model->get_by_id($id);
        if (!$notifikasi || $notifikasi->id_user != $user_id || $notifikasi->role != $role) {
            show_404();
        }
        
        $this->Notifikasi_model->mark_as_read($id);
        $this->session->set_flashdata('success', 'Notifikasi ditandai sudah dibaca.');
        
        if ($notifikasi->link) {
            redirect($notifikasi->link);
        } else {
            redirect('Dashboard');
        }
    }

    public function mark_all_read() {
        $user_id = $this->session->userdata('user_id');
        $role = $this->session->userdata('role');
        
        if (!$user_id) {
            show_404();
        }
        
        $this->Notifikasi_model->mark_all_as_read($user_id, $role);
        $this->session->set_flashdata('success', 'Semua notifikasi ditandai sudah dibaca.');
        redirect('Dashboard');
    }
}



