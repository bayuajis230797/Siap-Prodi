<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Pendaftaran_sidang_pkl Controller
 * Menangani pendaftaran sidang PKL oleh mahasiswa
 */
class Pendaftaran_sidang_pkl extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->check_role('mahasiswa');
        $this->load->model('Pkl_pendaftaran_sidang_model');
        $this->load->model('Pkl_berkas_sidang_upload_model');
        $this->load->model('Pkl_berkas_sidang_model');
        $this->load->model('Pkl_pengajuan_model');
        $this->load->model('Mahasiswa_pkl_model');
        $this->load->model('Tahun_akademik_model');
        $this->load->library('form_validation');
        $this->load->helper('google_drive');
        $this->load->helper('notifikasi');
    }

    /**
     * Index - form pendaftaran sidang PKL
     */
    public function index() {
        $id_mahasiswa = $this->session->userdata('ref_id');
        $tahun_aktif = $this->Tahun_akademik_model->get_aktif();
        
        if (!$tahun_aktif) {
            $this->session->set_flashdata('error', 'Tidak ada tahun akademik aktif.');
            redirect('Halaman_utama');
        }

        // Cek apakah mahasiswa terdaftar PKL
        if (!$this->Mahasiswa_pkl_model->is_registered($id_mahasiswa, $tahun_aktif->id)) {
            $this->session->set_flashdata('error', 'Anda belum terdaftar sebagai peserta PKL.');
            redirect('Halaman_utama');
        }

        // Cek apakah sudah layak sidang
        $pengajuan = $this->Pkl_pengajuan_model->get_by_mahasiswa($id_mahasiswa, $tahun_aktif->id);
        if (!$pengajuan || !$pengajuan->is_layak_sidang || $pengajuan->status_acc_judul !== 'acc') {
            $this->session->set_flashdata('error', 'Anda belum layak sidang. Pastikan pembimbing sudah memberikan ACC layak sidang.');
            redirect('Halaman_utama');
        }

        // Cek apakah sudah ada pendaftaran
        $pendaftaran = $this->Pkl_pendaftaran_sidang_model->get_by_mahasiswa($id_mahasiswa, $tahun_aktif->id);
        
        // Ambil berkas yang sudah diupload
        $berkas_uploaded = array();
        if ($pendaftaran) {
            $berkas_uploaded = $this->Pkl_berkas_sidang_upload_model->get_by_pendaftaran($pendaftaran->id);
        }

        // Ambil daftar berkas yang diperlukan
        $berkas_list = $this->Pkl_berkas_sidang_model->get_all(true);

        $data = array(
            'title' => 'Pendaftaran Sidang PKL',
            'page_title' => 'Pendaftaran Sidang PKL',
            'breadcrumb' => array(
                array('label' => 'PKL', 'url' => '#'),
                array('label' => 'Pendaftaran Sidang', 'active' => true)
            ),
            'sidebar_menu' => generate_sidebar_menu('mahasiswa'),
            'pendaftaran' => $pendaftaran,
            'berkas_list' => $berkas_list,
            'berkas_uploaded' => $berkas_uploaded,
            'pengajuan' => $pengajuan,
            'tahun_aktif' => $tahun_aktif
        );

        $data['content'] = $this->load->view('mahasiswa/pendaftaran_sidang_pkl/index', $data, true);
        $this->load->view('layouts/main', $data);
    }

    /**
     * Submit pendaftaran sidang PKL
     */
    public function submit() {
        $id_mahasiswa = $this->session->userdata('ref_id');
        $tahun_aktif = $this->Tahun_akademik_model->get_aktif();
        
        if (!$tahun_aktif) {
            $this->session->set_flashdata('error', 'Tidak ada tahun akademik aktif.');
            redirect('Halaman_utama');
        }

        // Cek apakah sudah layak sidang
        $pengajuan = $this->Pkl_pengajuan_model->get_by_mahasiswa($id_mahasiswa, $tahun_aktif->id);
        if (!$pengajuan || !$pengajuan->is_layak_sidang || $pengajuan->status_acc_judul !== 'acc') {
            $this->session->set_flashdata('error', 'Anda belum layak sidang.');
            redirect('Halaman_utama');
        }

        // Cek apakah sudah ada pendaftaran
        $pendaftaran = $this->Pkl_pendaftaran_sidang_model->get_by_mahasiswa($id_mahasiswa, $tahun_aktif->id);
        
        // Ambil daftar berkas wajib
        $berkas_list = $this->Pkl_berkas_sidang_model->get_all(true);
        $berkas_wajib = array();
        foreach ($berkas_list as $berkas) {
            if ($berkas->wajib) {
                $berkas_wajib[] = $berkas->id;
            }
        }

        // Validasi link wajib
        $errors = array();
        foreach ($berkas_wajib as $id_berkas) {
            $link_berkas = trim($this->input->post('link_berkas_' . $id_berkas));
            if (empty($link_berkas)) {
                // Cek apakah sudah pernah diupload
                if ($pendaftaran) {
                    $existing = $this->Pkl_berkas_sidang_upload_model->get_by_pendaftaran_berkas($pendaftaran->id, $id_berkas);
                    if (!$existing) {
                        $errors[] = "Berkas wajib belum diisi";
                        break;
                    }
                    if (!is_valid_google_drive_link((string) $existing->file_path)) {
                        $errors[] = "Terdapat link berkas wajib yang belum valid. Silakan perbarui link Google Drive.";
                        break;
                    }
                } else {
                    $errors[] = "Berkas wajib belum diisi";
                    break;
                }
            } else {
                if (!is_valid_google_drive_link($link_berkas)) {
                    $errors[] = "Link wajib menggunakan format Google Drive/Docs yang valid";
                    break;
                }
            }
        }

        if (!empty($errors)) {
            $this->session->set_flashdata('error', implode(', ', $errors));
            redirect('Pendaftaran_sidang_pkl');
        }

        // Buat atau update pendaftaran
        if (!$pendaftaran) {
            $pendaftaran_data = array(
                'id_mahasiswa' => $id_mahasiswa,
                'id_tahun_akademik' => $tahun_aktif->id,
                'status' => 'menunggu'
            );
            $pendaftaran_id = $this->Pkl_pendaftaran_sidang_model->create($pendaftaran_data);
        } else {
            $pendaftaran_id = $pendaftaran->id;
            // Update status jika ditolak sebelumnya
            if ($pendaftaran->status == 'ditolak') {
                $this->Pkl_pendaftaran_sidang_model->update($pendaftaran_id, array('status' => 'menunggu'));
            }
        }

        // Simpan link berkas
        foreach ($berkas_list as $berkas) {
            $field_name = 'link_berkas_' . $berkas->id;
            $link_berkas = trim($this->input->post($field_name));
            
            if (!empty($link_berkas)) {
                if (!is_valid_google_drive_link($link_berkas)) {
                    continue; // Skip jika bukan link Google Drive
                }
                $normalized_link = normalize_google_drive_link($link_berkas);
                
                // Cek apakah sudah ada upload sebelumnya
                $existing = null;
                if ($pendaftaran) {
                    $existing = $this->Pkl_berkas_sidang_upload_model->get_by_pendaftaran_berkas($pendaftaran_id, $berkas->id);
                }
                
                // Nama file dari nama berkas
                $file_name = $berkas->nama_berkas;
                
                if ($existing) {
                    // Hapus file lama hanya jika bukan link (backward compatibility)
                    if (strpos($existing->file_path, 'http') === false && file_exists($existing->file_path)) {
                        unlink($existing->file_path);
                    }
                    // Update
                    $this->Pkl_berkas_sidang_upload_model->update($existing->id, array(
                        'file_path' => $normalized_link,
                        'file_name' => $file_name,
                        'file_size' => null
                    ));
                } else {
                    // Create
                    $this->Pkl_berkas_sidang_upload_model->create(array(
                        'id_pendaftaran_sidang' => $pendaftaran_id,
                        'id_berkas_sidang' => $berkas->id,
                        'file_path' => $normalized_link,
                        'file_name' => $file_name,
                        'file_size' => null
                    ));
                }
            }
        }

        send_in_app_notification_by_role(
            'sekprodi',
            'Pendaftaran Sidang PKL Baru',
            'Ada pendaftaran sidang PKL baru yang menunggu verifikasi berkas.',
            site_url('Pkl_verifikasi_berkas_sidang')
        );

        $this->session->set_flashdata('success', 'Pendaftaran sidang berhasil dikirim. Menunggu persetujuan dari sekprodi.');
        redirect('Pendaftaran_sidang_pkl');
    }
}





