<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0"><i class="fas fa-comments"></i> Pesan</h3>
                <a href="<?php echo site_url('Chat/compose'); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-pen"></i> Tulis Pesan
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($conversations)): ?>
                    <div class="p-4 text-center text-muted">Belum ada percakapan. Klik "Tulis Pesan" untuk memulai.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Percakapan</th>
                                    <th>Pesan Terakhir</th>
                                    <th width="12%" class="text-center">Belum dibaca</th>
                                    <th width="10%" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($conversations as $c): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars(chat_conversation_title($c, $user_id)); ?></strong>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php if ($c->last_message_at): ?>
                                                    <?php echo date('d/m/Y H:i', strtotime($c->last_message_at)); ?> —
                                                    <?php echo htmlspecialchars(mb_strimwidth(strip_tags($c->last_message ?? ''), 0, 80, '...')); ?>
                                                <?php else: ?>
                                                    —
                                                <?php endif; ?>
                                            </small>
                                        </td>
                                        <td class="text-center">
                                            <?php if ((int) $c->unread_count > 0): ?>
                                                <span class="badge badge-danger"><?php echo (int) $c->unread_count; ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">0</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo site_url('Chat/thread/' . $c->id); ?>" class="btn btn-primary btn-sm">Buka</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <?php if (!empty($pagination)): ?>
            <div class="card-footer clearfix">
                <?php echo $pagination; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
