<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title mb-0"><?php echo htmlspecialchars($page_title); ?></h3>
                <div class="card-tools">
                    <?php if ($conversation->type === 'broadcast'): ?>
                        <a href="<?php echo site_url('Chat/broadcast/' . $conversation->id); ?>" class="btn btn-info btn-sm">Statistik Dibaca</a>
                    <?php endif; ?>
                    <a href="<?php echo site_url('Chat'); ?>" class="btn btn-secondary btn-sm">Kembali</a>
                </div>
            </div>
            <div class="card-body" style="max-height: 450px; overflow-y: auto;" id="chatThreadBox">
                <?php if (empty($messages)): ?>
                    <p class="text-muted">Belum ada pesan.</p>
                <?php else: ?>
                    <?php foreach ($messages as $msg): ?>
                        <?php $is_mine = ((int) $msg->sender_user_id === $user_id); ?>
                        <div class="mb-3 <?php echo $is_mine ? 'text-right' : ''; ?>">
                            <div class="d-inline-block p-2 rounded <?php echo $is_mine ? 'bg-primary text-white' : 'bg-light border'; ?>" style="max-width: 85%; text-align: left;">
                                <small class="d-block <?php echo $is_mine ? 'text-white-50' : 'text-muted'; ?>">
                                    <strong><?php echo htmlspecialchars(chat_display_name($msg->sender_user_id)); ?></strong>
                                    · <?php echo date('d/m/Y H:i', strtotime($msg->created_at)); ?>
                                    <?php if ($msg->is_priority): ?>
                                        <span class="badge badge-warning">Penting</span>
                                    <?php endif; ?>
                                </small>
                                <div><?php echo nl2br(htmlspecialchars($msg->body)); ?></div>
                                <?php if ($is_mine && isset($read_map[$msg->id])): ?>
                                    <?php $rc = $read_map[$msg->id]; ?>
                                    <small class="d-block mt-1 <?php echo $is_mine ? 'text-white-50' : ''; ?>">
                                        <?php if ($rc && $rc->is_read): ?>
                                            <i class="fas fa-check-double"></i> Dibaca <?php echo date('d/m/Y H:i', strtotime($rc->read_at)); ?>
                                        <?php else: ?>
                                            <i class="fas fa-check"></i> Belum dibaca
                                        <?php endif; ?>
                                    </small>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <?php echo form_open('Chat/reply/' . $conversation->id); ?>
                    <div class="form-group mb-2">
                        <textarea name="body" class="form-control" rows="3" placeholder="Tulis balasan..." required></textarea>
                    </div>
                    <?php if ($this->session->userdata('role') !== 'mahasiswa'): ?>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="is_priority" value="1" id="is_priority_reply">
                            <label class="form-check-label" for="is_priority_reply">Tandai sebagai pesan penting (wajib dibaca saat login)</label>
                        </div>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Kirim</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var box = document.getElementById('chatThreadBox');
    if (box) box.scrollTop = box.scrollHeight;
});
</script>
