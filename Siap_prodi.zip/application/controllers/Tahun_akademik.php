<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Tahun Akademik Controller
 * Mengelola tahun akademik dan kenaikan semester otomatis
 */
class Tahun_akademik extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->check_role('admin');
        $this->load->model('Tahun_akademik_model');
        $this->load->model('Mahasiswa_model');
        $this->load->model('Kurikulum_model');
        $this->load->model('Mata_kuliah_aktif_model');
        $this->load->model('Mapping_dosen_mk_model');
    }

    /**
     * List semua tahun akademik dengan pagination
     */
    public function index() {
        $this->load->library('pagination');
        
        // Ambil parameter per_page dari GET, default 10
        $per_page = $this->input->get('per_page') ? (int)$this->input->get('per_page') : 10;
        $per_page = in_array($per_page, [10, 25, 50, 100]) ? $per_page : 10;
        
        // Pagination config
        $config['base_url'] = site_url('Tahun_akademik/index');
        $config['total_rows'] = $this->Tahun_akademik_model->count_all();
        $config['per_page'] = $per_page;
        $config['uri_segment'] = 3;
        
        // Tambahkan per_page ke query string
        if ($per_page != 10) {
            $config['suffix'] = '?per_page=' . $per_page;
            $config['first_url'] = site_url('Tahun_akademik/index?per_page=' . $per_page);
        }
        $config['use_page_numbers'] = TRUE;
        $config['first_link'] = '&laquo; Awal';
        $config['last_link'] = 'Akhir &raquo;';
        $config['next_link'] = '&gt;';
        $config['prev_link'] = '&lt;';
        $config['full_tag_open'] = '<ul class="pagination pagination-sm m-0 float-right">';
        $config['full_tag_close'] = '</ul>';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['attributes'] = array('class' => 'page-link');
        
        $this->pagination->initialize($config);
        
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 1;
        $offset = ($page - 1) * $config['per_page'];
        
        $data['tahun_akademik'] = $this->Tahun_akademik_model->get_all($config['per_page'], $offset);
        $data['pagination'] = $this->pagination->create_links();
        $data['total_rows'] = $config['total_rows'];
        $data['per_page'] = $per_page;
        
        $data['title'] = 'Tahun Akademik';
        $data['page_title'] = 'Manajemen Tahun Akademik';
        $data['breadcrumb'] = array(
            array('label' => 'Tahun Akademik', 'active' => true)
        );
        $data['sidebar_menu'] = generate_sidebar_menu('admin');
        $data['content'] = $this->load->view('tahun_akademik/index', $data, true);
        $this->load->view('layouts/main', $data);
    }

    /**
     * Form tambah tahun akademik
     */
    public function create() {
        if ($this->input->method() === 'post') {
            $this->form_validation->set_rules('tahun_akademik', 'Tahun Akademik', 'required|trim');
            $this->form_validation->set_rules('semester', 'Semester', 'required|trim');
            $this->form_validation->set_rules('tgl_mulai', 'Tanggal Mulai', 'required|trim');
            $this->form_validation->set_rules('tgl_selesai', 'Tanggal Selesai', 'required|trim');

            if ($this->form_validation->run() == FALSE) {
                $data['title'] = 'Tambah Tahun Akademik';
                $data['page_title'] = 'Tambah Tahun Akademik';
                $data['breadcrumb'] = array(
                    array('label' => 'Tahun Akademik', 'url' => site_url('Tahun_akademik')),
                    array('label' => 'Tambah', 'active' => true)
                );
                $data['sidebar_menu'] = generate_sidebar_menu('admin');
                $data['content'] = $this->load->view('tahun_akademik/create', $data, true);
                $this->load->view('layouts/main', $data);
            } else {
                $data = array(
                    'tahun_akademik' => $this->input->post('tahun_akademik'),
                    'semester' => $this->input->post('semester'),
                    'tgl_mulai' => $this->input->post('tgl_mulai'),
                    'tgl_selesai' => $this->input->post('tgl_selesai'),
                    'is_aktif' => 0
                );

                if ($this->Tahun_akademik_model->create($data)) {
                    $this->session->set_flashdata('success', 'Tahun akademik berhasil ditambahkan.');
                    redirect('Tahun_akademik');
                } else {
                    $this->session->set_flashdata('error', 'Gagal menambahkan tahun akademik.');
                    redirect('Tahun_akademik/create');
                }
            }
        } else {
            $data['title'] = 'Tambah Tahun Akademik';
            $data['page_title'] = 'Tambah Tahun Akademik';
            $data['breadcrumb'] = array(
                array('label' => 'Tahun Akademik', 'url' => site_url('Tahun_akademik')),
                array('label' => 'Tambah', 'active' => true)
            );
            $data['sidebar_menu'] = generate_sidebar_menu('admin');
            $data['content'] = $this->load->view('tahun_akademik/create', $data, true);
            $this->load->view('layouts/main', $data);
        }
    }

    /**
     * Aktifkan tahun akademik, naikkan semester mahasiswa, dan set mata kuliah aktif
     */
    public function activate($id) {
        $tahun_akademik = $this->Tahun_akademik_model->get_by_id($id);
        
        if (!$tahun_akademik) {
            $this->session->set_flashdata('error', 'Tahun akademik tidak ditemukan.');
            redirect('Tahun_akademik');
        }

        // Cek tahun akademik yang sedang aktif
        $tahun_aktif_sebelumnya = $this->Tahun_akademik_model->get_aktif();
        
        // Nonaktifkan semua tahun akademik
        $this->Tahun_akademik_model->deactivate_all();
        
        // Aktifkan tahun akademik yang dipilih
        if ($this->Tahun_akademik_model->activate($id)) {
            $affected_mhs = 0;
            $affected_mk = 0;
            
            // Hanya recalculate jika tahun akademik benar-benar berubah
            // Cek apakah tahun akademik yang diaktifkan berbeda dengan yang sebelumnya
            $tahun_berubah = true;
            if ($tahun_aktif_sebelumnya) {
                // Bandingkan tahun akademik dan semester
                if ($tahun_aktif_sebelumnya->tahun_akademik == $tahun_akademik->tahun_akademik && 
                    $tahun_aktif_sebelumnya->semester == $tahun_akademik->semester) {
                    $tahun_berubah = false;
                }
            }
            
            if ($tahun_berubah) {
                // Recalculate semester aktif untuk semua mahasiswa berdasarkan tahun akademik baru
                // Ini akan menghitung ulang semester berdasarkan angkatan dan tahun akademik
                // Method ini juga akan otomatis update kelas (1A -> 2A, 1B -> 2B, dll)
                $affected_mhs = $this->Mahasiswa_model->recalculate_semester_all($tahun_akademik);
            }
            
            // Set mata kuliah aktif berdasarkan tahun akademik (selalu update)
            $affected_mk = $this->set_mata_kuliah_aktif($tahun_akademik);
            
            $message = 'Tahun akademik berhasil diaktifkan. ';
            if ($tahun_berubah && $affected_mhs > 0) {
                $message .= 'Semester dan kelas ' . $affected_mhs . ' mahasiswa aktif telah diupdate. ';
            }
            $message .= 'Mata kuliah aktif untuk ' . $affected_mk . ' kurikulum telah diupdate.';
            
            $this->session->set_flashdata('success', $message);
        } else {
            $this->session->set_flashdata('error', 'Gagal mengaktifkan tahun akademik.');
        }
        
        redirect('Tahun_akademik');
    }

    /**
     * Set mata kuliah aktif untuk semua kurikulum berdasarkan tahun akademik
     * Logika: Hitung semester aktif per kurikulum berdasarkan selisih tahun
     * 
     * Contoh:
     * - Tahun Akademik: 2025 ganjil, Kurikulum: 2022
     *   Semester aktif: (2025 - 2022) * 2 + 1 (ganjil) = 7
     * - Tahun Akademik: 2025 genap, Kurikulum: 2022
     *   Semester aktif: (2025 - 2022) * 2 + 2 (genap) = 8
     */
    private function set_mata_kuliah_aktif($tahun_akademik) {
        // Ambil tahun dari tahun_akademik (format: 2024/2025)
        $tahun_parts = explode('/', $tahun_akademik->tahun_akademik);
        $tahun_akademik_start = intval($tahun_parts[0]);
        
        // Tentukan nilai semester (ganjil = 1, genap = 2)
        $semester_value = ($tahun_akademik->semester == 'ganjil') ? 1 : 2;
        
        // Ambil semua kurikulum aktif
        $kurikulum_list = $this->Kurikulum_model->get_all_aktif();
        
        // Hapus mata kuliah aktif lama untuk tahun akademik ini
        $this->Mata_kuliah_aktif_model->clear_by_tahun_akademik($tahun_akademik->id);
        
        $kurikulum_count = 0;
        
        foreach ($kurikulum_list as $kurikulum) {
            // Hitung semester aktif untuk kurikulum ini
            $selisih_tahun = $tahun_akademik_start - $kurikulum->tahun_berlaku;
            $semester_aktif = ($selisih_tahun * 2) + $semester_value;
            
            // Batasi maksimal semester 8
            if ($semester_aktif > 8) {
                $semester_aktif = 8;
            }
            
            // Ambil semua kurikulum_detail untuk kurikulum ini
            $this->db->where('id_kurikulum', $kurikulum->id);
            $kurikulum_details = $this->db->get('kurikulum_detail')->result();
            
            // Set mata kuliah aktif untuk semester yang sesuai
            foreach ($kurikulum_details as $kd) {
                if ($kd->semester == $semester_aktif) {
                    $id_mata_kuliah_aktif = $this->Mata_kuliah_aktif_model->set_aktif(
                        $kurikulum->id,
                        $kd->id,
                        $tahun_akademik->id,
                        $semester_aktif
                    );
                    
                    // Re-link mapping yang id_mata_kuliah_aktif-nya NULL untuk tahun akademik ini
                    // Mapping yang id_mata_kuliah_aktif-nya NULL adalah mapping yang terputus saat mata_kuliah_aktif dihapus
                    $this->db->where('id_tahun_akademik', $tahun_akademik->id);
                    $this->db->where('id_mata_kuliah_aktif IS NULL', NULL, FALSE);
                    $this->db->where('kelas IS NOT NULL', NULL, FALSE);
                    $mapping_terputus = $this->db->get('mapping_dosen_mk')->result();
                    
                    // Cari mapping yang sesuai berdasarkan kurikulum_detail
                    // Mapping yang terputus harus memiliki informasi yang sama dengan mata_kuliah_aktif yang baru
                    foreach ($mapping_terputus as $mapping) {
                        // Cek apakah mapping ini untuk kurikulum_detail yang sama
                        // Kita perlu cek berdasarkan informasi yang tersimpan di mapping
                        // Karena id_mata_kuliah_aktif NULL, kita perlu cara lain untuk match
                        // Solusi: ambil dari mapping yang sudah ada id_mata_kuliah_aktif untuk tahun akademik yang sama
                        // dan cek apakah kurikulum_detail-nya sama
                        
                        // Ambil mapping lain yang masih terhubung untuk referensi
                        // Atau kita bisa simpan id_kurikulum_detail di mapping (tapi itu perubahan besar)
                        // Alternatif: re-link berdasarkan pola yang sama (kelas, dosen, dll)
                        // Untuk sementara, kita skip re-link otomatis dan biarkan user re-link manual
                        // Tapi kita bisa tambahkan method untuk re-link manual nanti
                    }
                }
            }
            
            $kurikulum_count++;
        }
        
        // Re-link mapping yang terputus setelah semua mata_kuliah_aktif di-regenerate
        $this->relink_mapping_terputus($tahun_akademik->id);
        
        return $kurikulum_count;
    }

    /**
     * Re-link mapping yang terputus (id_mata_kuliah_aktif = NULL) dengan mata_kuliah_aktif yang baru
     */
    private function relink_mapping_terputus($id_tahun_akademik) {
        // Ambil semua mapping yang terputus untuk tahun akademik ini
        $this->db->where('id_tahun_akademik', $id_tahun_akademik);
        $this->db->where('id_mata_kuliah_aktif IS NULL', NULL, FALSE);
        $this->db->where('id_kurikulum_detail IS NOT NULL', NULL, FALSE); // Hanya yang punya id_kurikulum_detail
        $mapping_terputus = $this->db->get('mapping_dosen_mk')->result();
        
        if (empty($mapping_terputus)) {
            return;
        }
        
        // Untuk setiap mapping terputus, cari mata_kuliah_aktif yang sesuai berdasarkan id_kurikulum_detail
        foreach ($mapping_terputus as $mapping) {
            // Cari mata_kuliah_aktif yang baru dengan kurikulum_detail yang sama
            $mka_baru = $this->Mata_kuliah_aktif_model->get_by_kurikulum_detail_tahun($mapping->id_kurikulum_detail, $id_tahun_akademik);
            
            if ($mka_baru) {
                // Re-link mapping
                $this->db->where('id', $mapping->id);
                $this->db->update('mapping_dosen_mk', array(
                    'id_mata_kuliah_aktif' => $mka_baru->id
                ));
            }
        }
    }

    /**
     * Detail tahun akademik dengan statistik mahasiswa per semester
     */
    public function detail($id) {
        $tahun_akademik = $this->Tahun_akademik_model->get_by_id($id);
        
        if (!$tahun_akademik) {
            $this->session->set_flashdata('error', 'Tahun akademik tidak ditemukan.');
            redirect('Tahun_akademik');
        }

        // Ambil statistik mahasiswa per semester
        $data['statistik_semester'] = array();
        for ($sem = 1; $sem <= 8; $sem++) {
            $this->db->where('status', 'aktif');
            $this->db->where('semester_aktif', $sem);
            $data['statistik_semester'][$sem] = $this->db->count_all_results('mahasiswa');
        }

        // Ambil info mata kuliah aktif per kurikulum (jika tahun akademik aktif)
        $data['kurikulum_mk_aktif'] = array();
        if ($tahun_akademik->is_aktif) {
            $kurikulum_list = $this->Kurikulum_model->get_all_aktif();
            $tahun_parts = explode('/', $tahun_akademik->tahun_akademik);
            $tahun_akademik_start = intval($tahun_parts[0]);
            $semester_value = ($tahun_akademik->semester == 'ganjil') ? 1 : 2;
            
            foreach ($kurikulum_list as $k) {
                $selisih_tahun = $tahun_akademik_start - $k->tahun_berlaku;
                $semester_aktif_kur = min(($selisih_tahun * 2) + $semester_value, 8);
                $mk_aktif = $this->Mata_kuliah_aktif_model->get_aktif_by_kurikulum_tahun($k->id, $tahun_akademik->id);
                
                $data['kurikulum_mk_aktif'][] = array(
                    'kurikulum' => $k,
                    'semester_aktif' => $semester_aktif_kur,
                    'jumlah_mk' => count($mk_aktif)
                );
            }
        }

        $data['tahun_akademik'] = $tahun_akademik;
        
        $data['title'] = 'Detail Tahun Akademik';
        $data['page_title'] = 'Detail Tahun Akademik: ' . $tahun_akademik->tahun_akademik . ' ' . ucfirst($tahun_akademik->semester);
        $data['breadcrumb'] = array(
            array('label' => 'Tahun Akademik', 'url' => site_url('Tahun_akademik')),
            array('label' => 'Detail', 'active' => true)
        );
        $data['sidebar_menu'] = generate_sidebar_menu('admin');
        $data['content'] = $this->load->view('tahun_akademik/detail', $data, true);
        $this->load->view('layouts/main', $data);
    }

    /**
     * Hapus tahun akademik
     */
    public function delete($id) {
        $tahun_akademik = $this->Tahun_akademik_model->get_by_id($id);
        
        if ($tahun_akademik && $tahun_akademik->is_aktif) {
            $this->session->set_flashdata('error', 'Tidak dapat menghapus tahun akademik yang sedang aktif.');
            redirect('Tahun_akademik');
        }

        if ($this->Tahun_akademik_model->delete($id)) {
            $this->session->set_flashdata('success', 'Tahun akademik berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus tahun akademik.');
        }
        redirect('Tahun_akademik');
    }
}

