<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('mahasiswa');
        return $query->row();
    }

    public function get_all($limit = null, $offset = null) {
        $this->db->select('m.*, k.nama_kurikulum, k.tahun_berlaku');
        $this->db->from('mahasiswa m');
        $this->db->join('kurikulum k', 'k.id = m.id_kurikulum', 'left');
        $this->db->order_by('m.angkatan', 'DESC');
        $this->db->order_by('m.nim', 'ASC');
        if ($limit !== null) {
            $this->db->limit($limit, $offset);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function count_all() {
        $this->db->from('mahasiswa');
        return $this->db->count_all_results();
    }

    public function get_by_nim($nim) {
        $this->db->where('nim', $nim);
        $query = $this->db->get('mahasiswa');
        return $query->row();
    }

    public function create($data) {
        $this->db->insert('mahasiswa', $data);
        return $this->db->insert_id();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        $this->db->update('mahasiswa', $data);
        return $this->db->affected_rows();
    }

    public function delete($id) {
        $this->db->where('id', $id);
        $this->db->delete('mahasiswa');
        return $this->db->affected_rows();
    }

    public function update_semester($id, $semester_baru) {
        $this->db->where('id', $id);
        $this->db->update('mahasiswa', array('semester_aktif' => $semester_baru));
        return $this->db->affected_rows();
    }

    /**
     * Recalculate semester aktif untuk semua mahasiswa berdasarkan tahun akademik baru.
     * Kelas cohort berbeda tidak digabung: jika target kelas sudah dipakai cohort lain
     * (mis. 7A naik ke 8A padahal 8A sudah terisi angkatan sebelumnya), maka cohort
     * yang baru masuk mendapat huruf kelas berikutnya (8B, 8C, dst).
     */
    public function recalculate_semester_all($tahun_akademik) {
        $tahun_parts = explode('/', $tahun_akademik->tahun_akademik);
        $tahun_akademik_start = intval($tahun_parts[0]);
        $semester_value = ($tahun_akademik->semester == 'ganjil') ? 1 : 2;

        $this->db->where('status', 'aktif');
        $mahasiswa = $this->db->get('mahasiswa')->result();

        // Pass 1: hitung semester baru + huruf preferensi per mahasiswa
        $plans = array();
        foreach ($mahasiswa as $mhs) {
            $selisih_tahun = $tahun_akademik_start - (int) $mhs->angkatan;
            $semester_baru = ($selisih_tahun * 2) + $semester_value;
            if ($semester_baru > 8) {
                $semester_baru = 8;
            }
            if ($semester_baru < 1) {
                $semester_baru = 1;
            }

            $huruf = $this->extract_huruf_kelas($mhs->kelas);
            // Cohort: angkatan + huruf asal (supaya rombongan tetap terpisah)
            $cohort_key = (string) ((int) $mhs->angkatan) . '|' . $huruf;

            $plans[] = array(
                'id' => (int) $mhs->id,
                'old_kelas' => $mhs->kelas,
                'old_semester' => (int) $mhs->semester_aktif,
                'semester_baru' => $semester_baru,
                'huruf' => $huruf,
                'angkatan' => (int) $mhs->angkatan,
                'cohort_key' => $cohort_key,
                // Prioritas: yang sudah di semester target (biasanya 8) pertahankan huruf lama
                'priority' => ((int) $mhs->semester_aktif === $semester_baru) ? 0 : 1,
            );
        }

        // Pass 2: alokasikan kelas tanpa menggabungkan cohort berbeda
        $assigned_by_kelas = array(); // kelas => cohort_key
        $cohort_kelas_map = array();  // semester|cohort_key => kelas final

        // Urutkan: prioritas tinggi dulu, lalu angkatan lebih tua, lalu huruf
        usort($plans, function ($a, $b) {
            if ($a['priority'] !== $b['priority']) {
                return $a['priority'] - $b['priority'];
            }
            if ($a['angkatan'] !== $b['angkatan']) {
                return $a['angkatan'] - $b['angkatan'];
            }
            return strcmp($a['huruf'], $b['huruf']);
        });

        foreach ($plans as &$plan) {
            $map_key = $plan['semester_baru'] . '|' . $plan['cohort_key'];
            if (isset($cohort_kelas_map[$map_key])) {
                $plan['kelas_baru'] = $cohort_kelas_map[$map_key];
                continue;
            }

            $candidate = $plan['semester_baru'] . $plan['huruf'];
            // Jika kelas sudah dipakai cohort lain, cari huruf berikutnya
            if (isset($assigned_by_kelas[$candidate]) && $assigned_by_kelas[$candidate] !== $plan['cohort_key']) {
                $candidate = $this->find_available_kelas_code(
                    $plan['semester_baru'],
                    $plan['huruf'],
                    $assigned_by_kelas,
                    $plan['cohort_key']
                );
            }

            $assigned_by_kelas[$candidate] = $plan['cohort_key'];
            $cohort_kelas_map[$map_key] = $candidate;
            $plan['kelas_baru'] = $candidate;
        }
        unset($plan);

        // Pass 3: simpan perubahan
        $updated = 0;
        foreach ($plans as $plan) {
            $need_update = false;
            $data = array();

            if ((int) $plan['old_semester'] !== (int) $plan['semester_baru']) {
                $data['semester_aktif'] = $plan['semester_baru'];
                $need_update = true;
            }
            if ((string) $plan['old_kelas'] !== (string) $plan['kelas_baru']) {
                $data['kelas'] = $plan['kelas_baru'];
                $need_update = true;
            }

            if ($need_update) {
                $this->db->where('id', $plan['id']);
                $this->db->update('mahasiswa', $data);
                $updated++;
            }
        }

        return $updated;
    }

    /**
     * Ambil huruf kelas dari kode kelas (1A -> A, 8G -> G)
     */
    private function extract_huruf_kelas($kelas) {
        if (!is_string($kelas) || trim($kelas) === '') {
            return 'A';
        }
        if (preg_match('/([A-Za-z])\s*$/', $kelas, $m)) {
            return strtoupper($m[1]);
        }
        return 'A';
    }

    /**
     * Cari kode kelas yang belum dipakai cohort lain pada semester yang sama.
     * Contoh: 8A sudah dipakai -> coba 8B, 8C, ...
     */
    private function find_available_kelas_code($semester, $start_huruf, $assigned_by_kelas, $cohort_key) {
        $letters = range('A', 'Z');
        $start_idx = array_search(strtoupper($start_huruf), $letters, true);
        if ($start_idx === false) {
            $start_idx = 0;
        }

        // Mulai dari huruf berikutnya setelah preferensi awal
        for ($i = $start_idx + 1; $i < count($letters); $i++) {
            $code = $semester . $letters[$i];
            if (!isset($assigned_by_kelas[$code]) || $assigned_by_kelas[$code] === $cohort_key) {
                return $code;
            }
        }
        // Fallback: scan dari A lagi
        for ($i = 0; $i < count($letters); $i++) {
            $code = $semester . $letters[$i];
            if (!isset($assigned_by_kelas[$code]) || $assigned_by_kelas[$code] === $cohort_key) {
                return $code;
            }
        }

        // Sangat jarang: semua huruf terpakai
        return $semester . $start_huruf . 'X';
    }

    /**
     * Naikkan semester untuk semua mahasiswa aktif yang semester < 8
     * DEPRECATED: Gunakan recalculate_semester_all() untuk menghitung ulang berdasarkan tahun akademik
     */
    public function naik_semester_all() {
        // Naikkan semester untuk semua mahasiswa aktif yang semester < 8
        // Dan update kelas sesuai dengan semester baru
        $this->db->where('status', 'aktif');
        $this->db->where('semester_aktif <', 8);
        
        // Ambil semua mahasiswa yang akan dinaikkan
        $mahasiswa = $this->db->get('mahasiswa')->result();
        
        $updated = 0;
        foreach ($mahasiswa as $mhs) {
            $semester_baru = $mhs->semester_aktif + 1;
            
            // Update kelas: ambil huruf kelas dari kelas lama, gabungkan dengan semester baru
            // Contoh: 1A -> 2A, 1B -> 2B, 1G -> 2G
            $kelas_baru = null;
            if ($mhs->kelas) {
                // Ambil huruf terakhir dari kelas (A, B, C, G, dll)
                $huruf_kelas = substr($mhs->kelas, -1);
                $kelas_baru = $semester_baru . $huruf_kelas;
            } else {
                // Jika belum ada kelas, set default ke A
                $kelas_baru = $semester_baru . 'A';
            }
            
            // Update semester dan kelas
            $this->db->where('id', $mhs->id);
            $this->db->update('mahasiswa', array(
                'semester_aktif' => $semester_baru,
                'kelas' => $kelas_baru
            ));
            $updated++;
        }
        
        return $updated;
    }

    /**
     * Generate kelas otomatis berdasarkan semester dan urutan
     * Format: {semester}{huruf} seperti 1A, 1B, 1C, 1G (untuk karyawan)
     */
    public function generate_kelas($semester, $is_karyawan = false) {
        if ($is_karyawan) {
            return $semester . 'G'; // G untuk kelas karyawan
        }
        
        // Untuk kelas reguler, hitung berapa banyak mahasiswa per semester
        $this->db->where('semester_aktif', $semester);
        $this->db->where('status', 'aktif');
        $count = $this->db->count_all_results('mahasiswa');
        
        // Tentukan huruf kelas berdasarkan jumlah mahasiswa
        // Setiap 40 mahasiswa = 1 kelas (A, B, C, dll)
        $kelas_index = floor($count / 40);
        $huruf = chr(65 + $kelas_index); // 65 = 'A', 66 = 'B', dll
        
        return $semester . $huruf;
    }

    /**
     * Get mahasiswa by kelas
     */
    public function get_by_kelas($kelas, $status = 'aktif') {
        $this->db->select('m.*, k.nama_kurikulum');
        $this->db->from('mahasiswa m');
        $this->db->join('kurikulum k', 'k.id = m.id_kurikulum', 'left');
        $this->db->where('m.kelas', $kelas);
        if ($status) {
            $this->db->where('m.status', $status);
        }
        $this->db->order_by('m.nim', 'ASC');
        
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Get statistik kelas per semester
     */
    public function get_statistik_kelas($semester = null) {
        if ($semester) {
            $this->db->where('semester_aktif', $semester);
        }
        $this->db->where('status', 'aktif');
        $this->db->select('kelas, COUNT(*) as jumlah');
        $this->db->group_by('kelas');
        $this->db->order_by('kelas', 'ASC');
        $query = $this->db->get('mahasiswa');
        return $query->result();
    }

    /**
     * Get daftar semua kelas yang ada
     */
    public function get_all_kelas($status = 'aktif') {
        $this->db->select('kelas, COUNT(*) as jumlah');
        $this->db->from('mahasiswa');
        $this->db->where('kelas IS NOT NULL');
        $this->db->where('kelas !=', '');
        if ($status) {
            $this->db->where('status', $status);
        }
        $this->db->group_by('kelas');
        $this->db->order_by('kelas', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }
}

