<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tahun_akademik_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_all($limit = null, $offset = null) {
        $this->db->order_by('tahun_akademik', 'DESC');
        $this->db->order_by('semester', 'DESC');
        if ($limit !== null) {
            $this->db->limit($limit, $offset);
        }
        $query = $this->db->get('tahun_akademik');
        return $query->result();
    }

    public function count_all() {
        return $this->db->count_all_results('tahun_akademik');
    }

    public function get_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('tahun_akademik');
        return $query->row();
    }

    public function get_aktif() {
        $this->db->where('is_aktif', 1);
        $this->db->limit(1);
        $query = $this->db->get('tahun_akademik');
        return $query->row();
    }

    public function create($data) {
        $this->db->insert('tahun_akademik', $data);
        return $this->db->insert_id();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        $this->db->update('tahun_akademik', $data);
        return $this->db->affected_rows();
    }

    public function deactivate_all() {
        $this->db->update('tahun_akademik', array('is_aktif' => 0));
        return $this->db->affected_rows();
    }

    public function activate($id) {
        // Nonaktifkan semua dulu
        $this->deactivate_all();
        
        // Aktifkan yang dipilih
        $this->db->where('id', $id);
        $this->db->update('tahun_akademik', array('is_aktif' => 1));
        return $this->db->affected_rows();
    }

    public function delete($id) {
        $this->db->where('id', $id);
        $this->db->delete('tahun_akademik');
        return $this->db->affected_rows();
    }
}

